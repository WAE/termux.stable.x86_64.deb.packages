#include "common.h"
#include "irc.h"

#define MODULE_NAME "irc/core"
