#ifndef __FE_CAPSICUM_H
#define __FE_CAPSICUM_H

void fe_capsicum_init(void);
void fe_capsicum_deinit(void);

#endif
