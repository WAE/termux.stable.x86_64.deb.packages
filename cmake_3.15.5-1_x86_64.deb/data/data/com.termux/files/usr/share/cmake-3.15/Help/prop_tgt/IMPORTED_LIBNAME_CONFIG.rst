IMPORTED_LIBNAME_<CONFIG>
-------------------------

<CONFIG>-specific version of :prop_tgt:`IMPORTED_LIBNAME` property.

Configuration names correspond to those provided by the project from
which the target is imported.
