Swift_DEPENDENCIES_FILE
-----------------------

This property sets the path for the Swift dependency file (swiftdep) for the
target.  If one is not specified, it will default to ``<TARGET>.swiftdeps``.
