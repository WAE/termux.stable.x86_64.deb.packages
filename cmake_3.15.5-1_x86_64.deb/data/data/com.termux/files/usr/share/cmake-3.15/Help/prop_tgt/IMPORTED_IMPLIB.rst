IMPORTED_IMPLIB
---------------

Full path to the import library for an ``IMPORTED`` target.

Set this to the location of the ``.lib`` part of a Windows DLL.  Ignored
for non-imported targets.
