Swift_MODULE_NAME
-----------------

This property specifies the name of the Swift module.  It is defaulted to the
name of the target.
