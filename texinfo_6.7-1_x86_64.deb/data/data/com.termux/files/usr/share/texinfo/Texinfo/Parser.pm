# This file is for use by pod2texi.
use Texinfo::ParserNonXS;

1;
